﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ELibraryMgmtSystemException.Exception1;

namespace ELibraryMgmtSystemBL.BusinessLayer
{
    public class DocumentTypeDetailsBL
    {

        Training_24Oct18_PuneEntities objDocTypeDbContext = null;

        public DocumentTypeDetailsBL()
        {
            objDocTypeDbContext = new Training_24Oct18_PuneEntities();
        }

        //
        public IEnumerable<Document_Type_details> DisplayDocTypeDetails()
        {
            IQueryable<Document_Type_details> docTypeiList;
            try
            {
                docTypeiList = from objDisci in objDocTypeDbContext.Document_Type_details
                            select objDisci;
            }
            catch (ELibraryMgmtSysException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return docTypeiList;
        }

        //retrieve by id
        public int getDocTypeId(string docTypename)
        {
            Document_Type_details objdocType;
            List<Document_Type_details> docTypeList = objDocTypeDbContext.Document_Type_details.ToList();
            try
            {
                objdocType = docTypeList.SingleOrDefault(doc => doc.Document_Type_Name == docTypename);
            }
            catch (ELibraryMgmtSysException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return objdocType.Document_Type_ID;
        }

    }
}
