﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ELibraryMgmtSystemException.Exception1;
using System.IO;

namespace ELibraryMgmtSystemBL.BusinessLayer
{
   public class DisciplineBL
    {
        Training_24Oct18_PuneEntities objDisciplineDbContext = null;

        //int index = 0;
        public DisciplineBL()
        {
            objDisciplineDbContext = new Training_24Oct18_PuneEntities();
        }


        //search by keyword
        public List<Document_Details> GetFiles(string filename)
        {
            try
            {
                var doclist = (from d in objDisciplineDbContext.Document_Details
                               where d.Document_Path.Contains(filename)
                               select d).ToList();
                return doclist;
            }
            catch (Exception ex)
            {
                throw ex;
            } 

        }

     



    }
}
