﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ELibraryMgmtSystemBL.BusinessLayer
{
   public class StringValueDocumentPath
    {
        public StringValueDocumentPath(string s)
        {
            _value = s;
        }
        public string Document
        {
            get
            {
                return _value;
            }
            set
            {
                _value = Document;
            }


        }
        string _value;
        

    }
}
