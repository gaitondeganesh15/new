﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ELibraryMgmtSystemException.Exception1;

namespace ELibraryMgmtSystemBL.BusinessLayer
{
    public class DocumentDetailsBL
    {
        Training_24Oct18_PuneEntities objDocumentDetailsDbcontext = null;

        public DocumentDetailsBL()
        {
            objDocumentDetailsDbcontext = new Training_24Oct18_PuneEntities();
        }

        //add document details
        public bool AddDocumentDetails(Document_Details objDocDetails)
        {
            bool isAdd = false;
            try
            {
                objDocumentDetailsDbcontext.Document_Details.Add(objDocDetails);
                isAdd = true;
                int i = objDocumentDetailsDbcontext.SaveChanges();
                if (i > 0)
                {


                    isAdd = true;
                }

            }
            catch (ELibraryMgmtSysException)
            {
                throw;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            return isAdd;
        }

      //public List<Document_Details> GetAllDocDetails()
      //  {
      //      var doclist = (from d in objDocumentDetailsDbcontext.Document_Details
      //                    where d.Document_Path.Contains("Web")
      //                    select d).ToList();
      //      return doclist;
      //      //var listDoc = (from doc in objDocumentDetailsDbcontext.Document_Details
      //      //               select doc).ToList();
      //      //return listDoc;
      //  }

    }
};
